package com.eomcs.lms.handler;

//Caller : App 클래스
//Callee : 명령 처리기
public interface Command {
  void excute();
  
}
